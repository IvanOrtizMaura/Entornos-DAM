import random
num = random.randrange(0,11)
for x in range(num):
    print(num)
else:
    print("Ya ha terminado el bucle")
for x in range (5):
    nombre = input("Escribe tu nombre")
    apellido2 = input("Escribe tu segundo apellido")
    apellido1 = input("Escribe tu primer apellido")
    dni = input("Escribe tu DNI")
    telefono = input("Escribe tu telefono ")
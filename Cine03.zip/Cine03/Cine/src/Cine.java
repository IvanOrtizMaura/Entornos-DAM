public class Cine {
    private String nombre;
    private int numAsientos;
    private int numFilas;
    private int numColumnas;
    private int arrayAsientos[][];

    public Cine (String nombre, int numFilas, int numColumnas){
        this.nombre = nombre;
        this.numAsientos = numFilas * numColumnas;
        this.numFilas = numFilas;
        this.numColumnas = numColumnas;
        this.arrayAsientos = new int [numFilas][numColumnas];
    }

    public void asignarAsientos (int f, int c){
        this.getArrayAsientos()[f][c] = 1;
    }

    public int asignarColumnas (){
        return (int)(Math.random()*numColumnas);

    }

    public int  asignarFilas (){
        return (int)(Math.random()*numFilas);
    }

    public void imprimirTodoArray(){
        for (int i=0; i<this.getNumFilas(); i++){
            for (int j=0; j<this.getNumColumnas();j++){
                System.out.print(this.getArrayAsientos()[i][j]);
            }
            System.out.println();
        }
    }

    public boolean compruebaArray() {
        int contador = 0;
        for (int i = 0; i < this.getNumFilas(); i++) {
            for (int j = 0; j < this.getNumColumnas(); j++) {
                if (this.getArrayAsientos()[i][j] == 1) {
                    contador++;
                }
            }
        }
        if (contador == numAsientos) {
            return true;
        }
        return false;
    }

    //Geters
    public String getNombre() {
        return nombre;
    }

    public int getNumAsientos() {
        return numAsientos;
    }

    public int getNumFilas() {
        return this.numFilas;
    }

    public int getNumColumnas() {
        return this.numColumnas;
    }

    public int[][] getArrayAsientos() {
        return this.arrayAsientos;
    }

    //Seters
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setNumAsientos(int numAsientos) {
        this.numAsientos = numAsientos;
    }

    public void setNumFilas(int numFilas) {
        this.numFilas = numFilas;
    }

    public void setNumColumnas(int numColumnas) {
        this.numColumnas = numColumnas;
    }

    public void setArrayAsientos(int[][] arrayAsientos) {
        this.arrayAsientos = arrayAsientos;
    }
}
import java.util.Scanner;

public class Principal {
    private static Scanner sc = new Scanner(System.in);

    public static void main (String[] args) {

        //Primer método, donde creamos el cine
        Cine c1 = crearCine();

        //Segundo método, donde creamos la pelicula para el cine
        Pelicula p1 = crearPelicula();


        while (!c1.compruebaArray()) {
            c1.asignarAsientos(c1.asignarFilas(), c1.asignarColumnas());
            c1.imprimirTodoArray();
            System.out.println();


        }


    }

    public static Cine crearCine(){
        System.out.println("Introduce un nombre para el Cine");
        String nombre = sc.nextLine();
        System.out.println("Introduce un numeor de filas para el Cine");
        int numFilas = sc.nextInt();
        System.out.println("Introduce un número de columnas para el Cine");
        int numColumnas = sc.nextInt();
        return new Cine(nombre, numFilas,numColumnas );
    }

    public static Pelicula crearPelicula(){
        System.out.println("Introduce el nombre de la pelicula para el Cine");
        String nombrePelicula = sc.nextLine();
        System.out.println("Introduce el precio de la pelicula");
        double precioPelicula = sc.nextDouble();
        System.out.println("Introduce la edad recomendada para ver la pelicula");
        int edadRecomendada = sc.nextInt();
        return new Pelicula(nombrePelicula, precioPelicula, edadRecomendada);
    }

    public static  Espectador crearEspectador(){
        String nombreEspectador = "Ivan";
        int edadEspectador = (int) (Math.random()*80);
        double carteraEspectador = (double) (Math.random()*1000);
        return new Espectador(nombreEspectador, edadEspectador, carteraEspectador);
    }
}

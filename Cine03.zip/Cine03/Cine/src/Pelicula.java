public class Pelicula {

    private String nombrePelicula;
    private double precioPelicula;
    private int edadRecomendada;

    //Constructor
    public  Pelicula(String nombrePelicula, double precioPelicula, int edadRecomendada){
        this.nombrePelicula = nombrePelicula;
        this.precioPelicula = precioPelicula;
        this.edadRecomendada = edadRecomendada;
    }
}

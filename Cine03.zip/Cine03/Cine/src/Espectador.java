public class Espectador {

    private String nombreEspectador;
    private int edadEspectador;
    private double carteraEspectador;

    // Constructor de espectador
    public Espectador (String nombreEspectador, int edadEspectador, double carteraEspectador){
        this.nombreEspectador = nombreEspectador;
        this.edadEspectador = edadEspectador;
        this.carteraEspectador = carteraEspectador;
    }
}

public class Software {
    private String nombreSoftware;
    private String versionSoftware;
    private double espacioNecesarioSoftware;
    private double memoriaNecesarioSoftware;

    //Constructor
    public Software(){}//Constructor por defecto
    public Software(String nombreSoftware, String versionSoftware, double espacioNecesarioSoftware, double memoriaNecesarioSoftware){
        this.nombreSoftware = nombreSoftware;
        this.versionSoftware = versionSoftware;
        this.espacioNecesarioSoftware = espacioNecesarioSoftware;
        this.memoriaNecesarioSoftware = memoriaNecesarioSoftware;
    }
    //Métodos

    @Override
    public String toString() {
        return "Nombre " + nombreSoftware + '\n' +
                "Versión " + versionSoftware + '\n' +
                "Espacio necesario " + espacioNecesarioSoftware +'\n' +
                "Memoria necesaria " + memoriaNecesarioSoftware + '\n' +
                "———————————————————————————————————————————————————" + '\n';

    }

    //Getters

    public double getEspacioNecesarioSoftware() {
        return espacioNecesarioSoftware;
    }

    public double getMemoriaNecesarioSoftware() {
        return memoriaNecesarioSoftware;
    }

    public String getNombreSoftware() {
        return nombreSoftware;
    }
}

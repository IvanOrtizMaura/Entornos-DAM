public class Principal {
    public static void main(String[] args) {
        //Estoy creando el ordenador
        Ordenador o1 = new Ordenador("Ivan",16,500);

        //Estoy diciendo que SO voy a instalar
        SistemaOperativo so1 = new SistemaOperativo("Windows11","v12","OEM", false, 40, 4);

        //Apartir de aquí estoy creando los programas que voy a instalar en el ordenador.
        Software s1 = new Software("Visual","v12",20,1);
        Software s2 = new Software("Visual","v12",10,1);
        Software s3 = new Software("Visual","v12",2,1);
        //Fin de instalación de programas para el ordeandor

        o1.instalacionSO(so1);
        so1.instalaciónSf(s1,o1);
        so1.instalaciónSf(s2,o1);
        so1.instalaciónSf(s3,o1);

        System.out.println("Este es el espacio que hay libre en el ordenador " + o1.getHddOrdenador());;
        System.out.println("Esta es la memoria que hay libre en el ordenador " + o1.getMemRAMOrdenador());

        System.out.println(so1.getListaSoftware());

        so1.desinstalaciónSoftware(s1,o1);

        o1.formatearOrdenador(so1);

    }
}

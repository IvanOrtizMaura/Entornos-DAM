public class Ordenador {
    //Atributos
    private String nombreOrdenador;
    private double memRAMOrdenador;
    private double hddOrdenador;


    //Constructor
    public Ordenador(String nombreOrdenador, double memRAMOrdenador, double hddOrdenador){
        this.nombreOrdenador = nombreOrdenador;
        this.memRAMOrdenador = memRAMOrdenador;
        this.hddOrdenador = hddOrdenador;

    }


    // Esto es el método para actualizar el SO y acutaulizar la memoria y espacio del ordenador.
    public void instalacionSO(SistemaOperativo OrdenadorSO){

        if(this.getHddOrdenador() > OrdenadorSO.getEspacioNecesarioSO() && this.getMemRAMOrdenador() >= OrdenadorSO.getMemoriaNecesariaSO()){
            setHddOrdenador(this.getHddOrdenador() - OrdenadorSO.getEspacioNecesarioSO());
            setMemRAMOrdenador(this.getMemRAMOrdenador() - OrdenadorSO.getMemoriaNecesariaSO());
        }else{
            System.out.println("No hay espacio o RAM suficiente para instalar el sistema operativos que quieres.");
        }
    }


    //Este método lo utilizo para formatear todo el ordenador
    public void formatearOrdenador(SistemaOperativo SO){

        this.setHddOrdenador(this.getHddOrdenador() + SO.getEspacioNecesarioSO() );

        this.setMemRAMOrdenador(this.getMemRAMOrdenador() + SO.getMemoriaNecesariaSO());

        for (Software i : SO.getListaSoftware()) {
            this.setHddOrdenador(this.getHddOrdenador() + i.getEspacioNecesarioSoftware());
            this.setMemRAMOrdenador(this.getMemRAMOrdenador() + i.getMemoriaNecesarioSoftware());
        }

        SO.getListaSoftware().clear();

        System.out.println("El espacio del ordenador es de " + this.getHddOrdenador() + " despues de formatearlo");

        System.out.println("La memoria del ordenador es de " + this.getMemRAMOrdenador() + " despues de formatearlo");
    }


    //Getters
    public double getMemRAMOrdenador() {
        return memRAMOrdenador;
    }

    public double getHddOrdenador() {
        return hddOrdenador;
    }


    //Setters

    public void setHddOrdenador(double hddOrdenador) {
        this.hddOrdenador = hddOrdenador;
    }

    public void setMemRAMOrdenador(double memRAMOrdenador) {
        this.memRAMOrdenador = memRAMOrdenador;
    }
}

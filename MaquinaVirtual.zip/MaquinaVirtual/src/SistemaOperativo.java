import java.util.ArrayList;

public class SistemaOperativo {
    //Atributo
    private String nombreSO;
    private String versionSO;
    private String arquitecturaSO;
    private boolean soloComandosSO;
    private double espacioNecesarioSO;
    private double memoriaNecesariaSO;
    private ArrayList<Software> listaSoftware = new ArrayList<Software>();

    //Constructores
    public SistemaOperativo(){}//Constructor pro defecto
    public SistemaOperativo(String nombreSO, String versionSO, String arquitecturaSO, boolean soloComandosSO, double espacioNecesarioSO, double memoriaNecesariaSO){
        this.nombreSO = nombreSO;
        this.versionSO = versionSO;
        this.arquitecturaSO = arquitecturaSO;
        this.soloComandosSO = soloComandosSO;
        this.espacioNecesarioSO = espacioNecesarioSO;
        this.memoriaNecesariaSO = memoriaNecesariaSO;
    }


    //En este método vamos a instalar el software que queremos y actualizar la memorai y el espacio.
    public void  instalaciónSf (Software SOSoftware, Ordenador o1){

        if(o1.getHddOrdenador() >  SOSoftware.getEspacioNecesarioSoftware() && o1.getMemRAMOrdenador() >= SOSoftware.getMemoriaNecesarioSoftware()){
            o1.setMemRAMOrdenador(o1.getMemRAMOrdenador() - SOSoftware.getMemoriaNecesarioSoftware());
            o1.setHddOrdenador(o1.getHddOrdenador() - SOSoftware.getEspacioNecesarioSoftware());
            this.getListaSoftware().add(SOSoftware);
        }else{
            System.out.println("No hay memoria o espacio suficiente para instalar el software que quieres");
        }
    }


    //Este método sirve para la desinstalación del programa
    public void desinstalaciónSoftware(Software SOSoftware, Ordenador o1){
        o1.setHddOrdenador( o1.getHddOrdenador() + SOSoftware.getEspacioNecesarioSoftware());

        o1.setMemRAMOrdenador( o1.getMemRAMOrdenador() + SOSoftware.getMemoriaNecesarioSoftware());

        this.getListaSoftware().remove(SOSoftware);

        System.out.println("Desinstalación del " + SOSoftware.getNombreSoftware() + " completa");
    }

    //Getters
    public double getMemoriaNecesariaSO() {
        return memoriaNecesariaSO;
    }

    public double getEspacioNecesarioSO() {
        return espacioNecesarioSO;
    }

    public ArrayList<Software> getListaSoftware() {
        return listaSoftware;
    }
}
